// Create the button element
const floatingBtn = document.createElement("a");
floatingBtn.href = "#";
floatingBtn.classList.add("floating-btn");
floatingBtn.innerHTML = "+";

// Style the button with JavaScript
const style = document.createElement("style");
style.textContent = `
    .floating-btn {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 50px;
        height: 50px;
        background-color: #007bff;
        color: #fff;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 24px;
        text-decoration: none;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        transition: background-color 0.3s;
        z-index: 1000;
    }
    .floating-btn:hover {
        background-color: #0056b3;
    }
`;

// Append the button and style to the document
document.head.appendChild(style);
document.body.appendChild(floatingBtn);

// Optional: Add click event for button action (e.g., scroll to top)
floatingBtn.addEventListener("click", (e) => {
  e.preventDefault();
  window.scrollTo({ top: 0, behavior: "smooth" });
});
